package com.mohallekedukandar;

public class CartObj {
    private String pid;
    private int Qunt;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public int getQunt() {
        return Qunt;
    }

    public void setQunt(int qunt) {
        Qunt = qunt;
    }
}
